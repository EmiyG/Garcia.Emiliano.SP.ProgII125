
package modelo;

import java.io.Serializable;
import utilidad.CSVSerializable;


public class NaveEspacial implements Comparable<NaveEspacial>, Serializable,CSVSerializable{
    private int id;
    private String nombre;
    private int capacidad;
    private Categoria categoria;

    public NaveEspacial(int id, String nombre, int capacidad, Categoria categoria){
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.categoria = categoria;
    }

    public String getNombre(){
        return nombre;
    }

    public Categoria getCategoria(){
        return categoria;
    }

    @Override
    public String toString(){
        return "id: " + id + " nombre: " + nombre + " capacidad: " + capacidad + " categoria: " + categoria;
    }

    
    public static NaveEspacial fromCSV(String csv){
        String[] partes = csv.split(",", -1); 
        if (partes.length != 4) {
            throw new IllegalArgumentException("Error.....El formato no es válido.");
        }
        int id = Integer.parseInt(partes[0]); 
        String nombre = partes[1]; 
        int capacidad = Integer.parseInt(partes[2]); 
        Categoria categoria = Categoria.valueOf(partes[3].toUpperCase()); 

        return new NaveEspacial(id, nombre, capacidad, categoria); 
    }
    
    
    @Override
    public int compareTo(NaveEspacial o){
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toCSV(){
        return id + "," + nombre + "," + capacidad + "," + categoria.toString();
    }
    
    

}
