
package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import servicio.Serializadora;
import utilidad.CSVSerializable;


public class Inventario<T extends CSVSerializable & Serializable>{
    private List<T> items;
    
    public Inventario(){
        this.items = new ArrayList<>();
    }
     
    public void agregar(T item){
        if(items != null){
            items.add(item);
        }
        
    }
   
    public T obtener(int indice){
        validarIndice(indice);
        return items.get(indice);
    }
    
    public void eliminar(int indice){
        validarIndice(indice);
        items.remove(indice);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio){
        List<T> toReturn = new ArrayList<>();
        
        for(T item: items ){
            if(criterio.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    } 
    
    public List<T> filtrarPorCategoria(Categoria categoria){
         return filtrar(item ->{
            if(item instanceof NaveEspacial nave){
                return nave.getCategoria()== categoria;
            }
            return false;
            });
    }
    
    public List<T> filtrarPorTitulo(String palabra){
        return filtrar(item ->{
        if(item instanceof NaveEspacial nave){
            return nave.getNombre().toLowerCase().contains(palabra.toLowerCase());
        }
        return false;});
    }
    
    public void ordenar(Comparator<? super T> comparator){
        items.sort(comparator);
    }
    
    public void ordenar(){
        items.sort((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public void guardarEnArchivo(String path){
        try{
            Serializadora.serializarLista( items, path);
            System.out.println("Inventario guardado con exito en binario: " + path);
        } catch(Exception ex) {
            System.out.println("Errorcuando se intento guardar en binario " + ex.getMessage());
        }
        
    }
   
    public void cargarDesdeArchivo(String path){
        try{
            List<T> listaItemsCargados = Serializadora.deserializarLista(path);
            if(listaItemsCargados != null){
                items.clear(); 
                items.addAll(listaItemsCargados); 
                System.out.println("Inventario cargado con exito.. de un archivo binario: " + path);
            }else{
                System.out.println("Error al cargar el archivo binario...");
            }
        }catch(Exception ex) {
            System.out.println("Erroral cargar desde archivo binario: " + ex.getMessage());
        }
    }

    public void guardarEnCSV(String path)throws IOException{
        File archivo = new File(path);

        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){

            bw.write("id,nombre,capacidad,categoria\n");
            for(T item : items) {
                if(item instanceof CSVSerializable cSVS) { 
                    bw.write(cSVS.toCSV() + "\n");
                }
            }
            System.out.println("\nInventario guardado con exito... en CSV: " + path);
        } catch (IOException ex) {
            System.out.println("Error.... al guardar en CSV: " + ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> convertidor)throws IOException, ClassNotFoundException{
        File archivo = new File(path);
        this.items.clear();

        try(BufferedReader br = new BufferedReader(new FileReader(archivo))){
            String linea;
            br.readLine(); 
            while((linea = br.readLine()) != null){
                try{
                    T item = convertidor.apply(linea);
                    agregar(item);
                }catch(IllegalArgumentException e){
                    System.out.println("Error...... al procesar la linea: " + linea + " - " + e.getMessage());
                    }
                
            }
            System.out.println("Inventario cargado con exito.. en archivo CSV.");
        } catch(IOException e){
            System.out.println("Error.... al cargar desde un archivo CSV: " + e.getMessage());
        }
    }
    
    public void paraCadaElemento(Consumer<T> accion){
        for(T item : items){
            accion.accept(item);
        }
    }
    
    private void validarIndice(int indice){
        if(indice < 0 || indice >= items.size()){
            throw   new IndexOutOfBoundsException("Error... Indice fuera de rango");
        }
        
    }
}
